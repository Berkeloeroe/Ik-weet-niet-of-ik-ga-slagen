<?php

class shared
{
    // De site is medewerker only, als je niet ingelogd bent moeten mensen het dus niet zien!
    public static function isLoggedIn($path = 'index.php')
    {
        session_start();
        
        if(!isset($_SESSION['username']))
        {
            header("Location: $path");
        }
    }

    public static function redirectToPath($escapes = 0, $file)
    {

        $path = '';

        if(isset($file))
        {
            for($i = 1; $i <= $escapes; $i++)
            {
                $path = $path .'../';
            }

            return $path .$file;
        }

    }
}

define("__DBNAME__", "excellenttaste");
define("__DBHOST__", "localhost");
define("__DBUSER__", "root");
define("__DBPASS__", "");
define("__DBCHARSET__", "utf8mb4");

// "Code" in de database om te laten weten of het voor de kok of barman is
define("__DRANKCODE__", "bar");
define("__ETENCODE__",  "kok");

?>