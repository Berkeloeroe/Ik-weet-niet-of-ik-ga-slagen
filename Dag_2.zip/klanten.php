<?php
    require_once 'databases/crud.php';
    require_once 'utils/shared.php';
    
    shared::isLoggedIn();

    $crud = new crud();
    $klanten = $crud->select("SELECT * FROM klant");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="stylesheets/shared.css">
</head>
<body>
    <div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="index.php">Home</a></li>
            <li><a href="reservering.php">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="gegevens.php" class="etMenu etMenuCurrent">Gegevens</a></li>
        </ul>
    </div>

    <div class="reserveringOverzicht centerForm" style="margin-top: 25px">
        <!-- Klanten overzicht -->
        <p class="importantText">Klanten Gegevens</p>
        <table>
            <thead>
                <tr>
                    <th scope="col" class="etOverzicht">Naam</th>
                    <th scope="col" class="etOverzicht">Telefoon</th>
                    <th scope="col" class="etOverzicht">E-mail</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($klanten as $klant): ?>
                    <tr>
                        <td class="etOverzicht"><?= $klant['naam']; ?></td>
                        <td class="etOverzicht"><?= $klant['telefoon']; ?></td>
                        <td class="etOverzicht"><?= $klant['email']; ?></td>
                        <td class="etOverzichtButton">
                            <a class="btn btn-primary mr-2 btn-sm" href="crud/gegevens/klanten/edit.php?klant_id=<?= $klant['klant_id'] ?>">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>


</body>
</html>