<?php
    require_once 'utils/shared.php';
    shared::isLoggedIn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="stylesheets/shared.css">
    <link rel="stylesheet" href="stylesheets/home.css">
</head>
<body>
    <div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="home.php" class="etMenuCurrent">Home</a></li>
            <li><a href="reservering.php">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="gegevens.php" class="etMenu">Gegevens</a></li>
        </ul>
    </div>

    <p class="etText">
        Welkom bij de reserverings- en bestellingapplicatie van Restaurant Excellent Taste! <br>
        Vul eerst een reservering in. Deze kan telefonisch binnenkomen of kan worden ingevoerd als gasten plaatsnemen aan een vrije tafel. <br>
        Daarna kan een bestelling worden opegnomen.
    </p>
</body>

</html>