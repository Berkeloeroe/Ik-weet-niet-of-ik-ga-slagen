<?php
    require_once 'databases/crud.php';
    require_once 'utils/shared.php';
    
    shared::isLoggedIn();

    $crud = new crud();
    $reserveringen = $crud->select("SELECT * FROM reservering INNER JOIN klant ON reservering.klant_id = klant.klant_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="stylesheets/shared.css">
</head>
<body>
    <div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="index.php">Home</a></li>
            <li><a href="#" class="etMenuCurrent">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="gegevens.php" class="etMenu">Gegevens</a></li>
        </ul>
    </div>

    <div class="reserveringOverzicht centerForm" style="margin-top: 25px">
        <a href="crud/reservering/create.php" class="importantText">Klik op mij om een reservering aan te maken!</a>
        <p class="importantText">Klik op de tafelnummer als je een bestelling wilt aanmaken!</p>

        <!-- Reservering overzicht -->
        <table>
            <thead>
                <tr>
                    <th scope="col" class="etOverzicht">Datum</th>
                    <th scope="col" class="etOverzicht">Tijd</th>
                    <th scope="col" class="etOverzicht">Tafel</th>
                    <th scope="col" class="etOverzicht">Klant</th>
                    <th scope="col" class="etOverzicht">Telefoon</th>
                    <th scope="col" class="etOverzicht">Aantal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($reserveringen as $reservering): ?>
                    <tr>
                        <td class="etOverzicht"><?= $reservering['datum']; ?></td>
                        <td class="etOverzicht"><?= $reservering['tijd']; ?></td>
                        <td class="etUniekFunctie etOverzicht"><a href="#"><?= $reservering['tafel']; ?></a></td>
                        <td class="etOverzicht"><?= $reservering['naam']; ?></td>
                        <td class="etOverzicht"><?= $reservering['telefoon']; ?></td>
                        <td class="etOverzicht"><?= $reservering['aantal_personen']; ?></td>
                        <td class="etOverzichtButton">
                            <a class="btn btn-primary mr-2 btn-sm" href="crud/reservering/edit.php?
                            reservering_id=<?= $reservering['reservering_id'];?>
                            &amp;klant_id=<?= $reservering['klant_id']; ?>
                            &amp;datum=<?= $reservering['datum']; ?>
                            &amp;tijd=<?= $reservering['tijd']; ?>
                            &amp;tafel=<?= $reservering['tafel']; ?>
                            &amp;klant=<?= $reservering['naam']; ?>
                            &amp;telefoon=<?= $reservering['telefoon']; ?>
                            &amp;aantal=<?= $reservering['aantal_personen']; ?>
                            ">Edit</a>
                        </td>  
                        <td class="etOverzichtButton">
                            <a class="btn btn-danger mr-2 btn-sm" href="crud/reservering/delete.php?reservering_id=<?= $reservering['reservering_id'];?>">Delete</a>
                        </td>  
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>


</body>
</html>