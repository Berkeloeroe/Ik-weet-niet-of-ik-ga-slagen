<?php
    require_once 'databases/crud.php';
    require_once 'utils/shared.php';
    
    shared::isLoggedIn();

    $type = $_GET['type'] == "dranken" || $_GET['type'] == "bar" ? __DRANKCODE__ : __ETENCODE__;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="stylesheets/shared.css">
</head>
<body>
    <div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="index.php">Home</a></li>
            <li><a href="reservering.php">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="gegevens.php" class="etMenu etMenuCurrent">Gegevens</a></li>
        </ul>
    </div>

    <div class="reserveringOverzicht centerForm" style="margin-top: 25px">
        <!-- Klanten overzicht -->
        <p class="importantText"><?= $type == __DRANKCODE__ ? 'Dranken' : 'Eten' ?> Gegevens</p>
        <a href="crud/gegevens/menu/create.php?type=<?= $type ?>" class="importantText">Klik op mij om <?= $type == __DRANKCODE__ ? 'drinken' : 'eten' ?> aan te maken!</a>
        <table>
            <thead>
                <tr>
                    <th scope="col" class="etOverzicht">Naam</th>
                    <th scope="col" class="etOverzicht">Prijs</th>
                    <th scope="col" class="etOverzicht">Code</th>
                    <th scope="col" class="etOverzicht">Gerechtsoort</th>
                    <th scope="col" class="etOverzicht">Gerechtcategorie</th>
                </tr>
            </thead>
        </table>
    </div>

</body>
</html>