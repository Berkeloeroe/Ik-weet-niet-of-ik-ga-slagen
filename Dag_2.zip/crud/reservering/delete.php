<?php
    require_once '../../utils/shared.php';

    shared::isLoggedIn(shared::redirectToPath(2, 'index.php'));

    if(isset($_GET))
    {
        print_r($_GET);

        require_once shared::redirectToPath(2, 'databases/crud.php');
        $crud = new crud();
        $crud->deleteReservering($_GET['reservering_id']);
    }

    header('Location: ' .shared::redirectToPath(2, 'reservering.php'));
?>