<?php

    require_once '../../utils/shared.php';

    shared::isLoggedIn(shared::redirectToPath(2, 'index.php'));

    if(isset($_POST) && isset($_POST['submit']))
    {
        require_once shared::redirectToPath(2, 'databases/crud.php');

        $crud = new crud();
        $crud->updateReservering($_GET['reservering_id'], $_POST['datum'], $_POST['tijd'], $_POST['tafel'], $_POST['aantal']);
        $crud->updateKlant($_GET['klant_id'], $_POST['klant'], $_POST['telefoon'], $crud->getKlant($_GET['klant_id'])['email']);

        header('Location: ' .shared::redirectToPath(2, 'reservering.php'));
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?= shared::redirectToPath(2, 'stylesheets/shared.css') ?>">
</head>
<body>
    <div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="<?= shared::redirectToPath(2, 'home.php') ?>">Home</a></li>
            <li><a href="<?= shared::redirectToPath(2, 'reservering.php') ?>" class="etMenuCurrent">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="<?= shared::redirectToPath(2, 'gegevens.php') ?>" class="etMenu">Gegevens</a></li>
        </ul>
    </div>

    <div class="centerForm" style="margin-top: 25px">
        <a href="<?= shared::redirectToPath(2, 'reservering.php') ?>" style="margin-bottom: 15px" class="importantText">Klik hier om de edit te annuleren</a>
        <form method="POST">
            <table>
                <thead>
                    <tr>
                        <th scope="col" class="etOverzicht">Datum</th>
                        <th scope="col" class="etOverzicht">Tijd</th>
                        <th scope="col" class="etOverzicht">Tafel</th>
                        <th scope="col" class="etOverzicht">Klant</th>
                        <th scope="col" class="etOverzicht">Telefoon</th>
                        <th scope="col" class="etOverzicht">Aantal</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="etOverzicht"><input type="date" name="datum" value=<?= $_GET['datum'] ?> required><br></td>
                        <td class="etOverzicht"><input type="text" name="tijd" value="<?= $_GET['tijd'] ?>" required><br></td>
                        <td class="etOverzicht"><input type="text" name="tafel" value="<?= $_GET['tafel'] ?>" required><br></td>
                        <td class="etOverzicht"><input type="text" name="klant" value="<?= $_GET['klant'] ?>" required><br></td>
                        <td class="etOverzicht"><input type="text" name="telefoon" value="<?= $_GET['telefoon'] ?>" required><br></td>
                        <td class="etOverzicht"><input type="text" name="aantal" value="<?= $_GET['aantal'] ?>" required><br></td> 
                    </tr>
                </tbody>
            </table>
            <input type="submit" value="Submit" name="submit">
        </form>
    </div>

</body>
</html>