<?php
    require_once '../../utils/shared.php';

    shared::isLoggedIn(shared::redirectToPath(2, 'index.php'));

    if(isset($_POST) && isset($_POST['submit']))
    {
        require_once shared::redirectToPath(2, 'databases/crud.php');

        $crud = new crud();
        $klantNum = $crud->addKlant($_POST['naam'], $_POST['telefoon'], $_POST['email']);
        $crud->addReservering($_POST['tafel'], $_POST['datum'], $_POST['tijd'], $_POST['aantal_personen'], $_POST['aantal_kinderen'], $_POST['status'], $_POST['datum_toegevoegd'], $_POST['allergien'], $_POST['opmerking'], $klantNum);

        header('Location: ' .shared::redirectToPath(2, 'reservering.php'));
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?= shared::redirectToPath(2, 'stylesheets/shared.css') ?>">
</head>
<body>
    <div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="<?= shared::redirectToPath(2, 'home.php') ?>">Home</a></li>
            <li><a href="<?= shared::redirectToPath(2, 'reservering.php') ?>" class="etMenuCurrent">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="<?= shared::redirectToPath(2, 'gegevens.php') ?>" class="etMenu">Gegevens</a></li>
        </ul>
    </div>

    <div class="centerForm" style="margin-top: 25px">
        <a href="<?= shared::redirectToPath(2, 'reservering.php') ?>" style="margin-bottom: 15px" class="importantText">Klik hier om de edit te annuleren</a>
        <form method="POST">
            <table>
                <thead>
                    <tr>
                        <th scope="col" class="etOverzicht">Tafelnummer</th>
                        <th scope="col" class="etOverzicht">Datum</th>
                        <th scope="col" class="etOverzicht">Tijd</th>
                        <th scope="col" class="etOverzicht">Aantal personen</th>
                        <th scope="col" class="etOverzicht">Aantal kinderen</th>
                        <th scope="col" class="etOverzicht">Status</th>
                        <th scope="col" class="etOverzicht">Datum toegevoegd</th>
                        <th scope="col" class="etOverzicht">Allergieën</th>
                        <th scope="col" class="etOverzicht">Opmerkingen</th>
                        <th scope="col" class="etOverzicht">Klant Naam</th>
                        <th scope="col" class="etOverzicht">Klant Telnummer</th>
                        <th scope="col" class="etOverzicht">Klant E-mail</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="etOverzicht"><input type="text" name="tafel" placeholder="Tafel nummer" required><br></td>
                        <td class="etOverzicht"><input type="date" name="datum" required><br></td>
                        <td class="etOverzicht"><input type="text" name="tijd" placeholder="Tijdstip" required><br></td>
                        <td class="etOverzicht"><input type="text" name="aantal_personen" placeholder="Aantal personen" required><br></td>
                        <td class="etOverzicht"><input type="text" name="aantal_kinderen" placeholder="Aantal kinderen" required><br></td>
                        <td class="etOverzicht"><input type="text" name="status" placeholder="status" required><br></td>
                        <td class="etOverzicht"><input type="date" name="datum_toegevoegd" required><br></td>
                        <td class="etOverzicht"><input type="text" name="allergien" placeholder="Allergieën"><br></td>
                        <td class="etOverzicht"><input type="text" name="opmerking" placeholder="Opmerkingen"><br></td>
                        <br>
                        <td class="etOverzicht"><input type="text" name="naam" placeholder="Naam klant" required><br></td>
                        <td class="etOverzicht"><input type="text" name="telefoon" placeholder="Telnummer klant" required><br></td>
                        <td class="etOverzicht"><input type="text" name="email" placeholder="E-mail klant" required><br></td>
                    </tr>
                </tbody>
            </table>

            <input type="submit" value="Submit" name="submit">
        </form>
    </div>

</body>
</html>