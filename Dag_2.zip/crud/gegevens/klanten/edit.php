<?php

    require_once '../../../utils/shared.php';
    require_once shared::redirectToPath(3, 'databases/crud.php');

    shared::isLoggedIn(shared::redirectToPath(3, 'index.php'));

    // Opzich kan ik hier hetzelfde doen als de reservering CRUD-
    // maar omdat de data makkelijker te pakken is (1 tabel zonder FKs etc) met een statement doe ik dat liever
    $crud = new crud();
    $klant = $crud->getKlant($_GET['klant_id']);

    if(isset($_POST) && isset($_POST['submit']))
    {
        $crud->updateKlant($_GET['klant_id'], $_POST['naam'], $_POST['telefoon'], $_POST['email']);
        header('Location: ' .shared::redirectToPath(3, 'klanten.php'));
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?= shared::redirectToPath(3, 'stylesheets/shared.css')?>">
</head>
<body>
<div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="<?= shared::redirectToPath(3, 'home.php') ?>">Home</a></li>
            <li><a href="<?= shared::redirectToPath(3, 'reservering.php') ?>">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="<?= shared::redirectToPath(3, 'gegevens.php') ?>" class="etMenu etMenuCurrent">Gegevens</a></li>
        </ul>
    </div>

    <div class="centerForm" style="margin-top: 25px">
        <a href="<?= shared::redirectToPath(3, 'klanten.php') ?>" style="margin-bottom: 15px" class="importantText">Klik hier om de edit te annuleren</a>
        <form method="POST">
            <table>
                <thead>
                    <tr>
                        <th scope="col" class="etOverzicht">Naam</th>
                        <th scope="col" class="etOverzicht">Telefoon</th>
                        <th scope="col" class="etOverzicht">E-mail</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="etOverzicht"><input type="text" name="naam" value="<?= $klant['naam'] ?>" required><br></td>
                        <td class="etOverzicht"><input type="text" name="telefoon" value=<?= $klant['telefoon'] ?> required><br></td>
                        <td class="etOverzicht"><input type="text" name="email" value=<?= $klant['email'] ?> required><br></td>
                    </tr>
                </tbody>
            </table>
            <input type="submit" value="Submit" name="submit">
        </form>
    </div>

</body>
</html>