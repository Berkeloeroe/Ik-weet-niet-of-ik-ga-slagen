<?php
    require_once '../../../utils/shared.php';
    require_once shared::redirectToPath(3, 'databases/crud.php');

    shared::isLoggedIn(shared::redirectToPath(3, 'index.php'));
    $type = $_GET['type'];
    $crud = new crud();
    $gerechtsoort = $crud->select("SELECT * FROM gerechtsoorten");

    if(isset($_POST) && isset($_POST['submit']))
    {
        // TODO: Maak het een SQL statement
        foreach($gerechtsoort as $soort)
        {
            if(strtolower($soort['naam']) == $_POST['gerechtsoort'])
            {
                echo $soort['gerechtsoort_id'];
                break;
            }
        }
    
        // header('Location: ' .shared::redirectToPath(3, "menu.php?type=$type"));
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?= shared::redirectToPath(3, 'stylesheets/shared.css')?>">
</head>
<body>
<div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="<?= shared::redirectToPath(3, 'home.php') ?>">Home</a></li>
            <li><a href="<?= shared::redirectToPath(3, 'reservering.php') ?>">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="<?= shared::redirectToPath(3, 'gegevens.php') ?>" class="etMenu etMenuCurrent">Gegevens</a></li>
        </ul>
    </div>


    <div class="centerForm" style="margin-top: 25px">
        <a href="<?= shared::redirectToPath(3, "menu.php?type=$type") ?>" style="margin-bottom: 15px" class="importantText">Klik hier om de edit te annuleren</a>
        <form method="POST">
            <table>
                <thead>
                    <tr>
                        <th scope="col" class="etOverzicht">Naam</th>
                        <th scope="col" class="etOverzicht">Prijs</th>
                        <th scope="col" class="etOverzicht">Gerechtsoort</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="etOverzicht"><input type="text" name="naam" required><br></td>
                        <td class="etOverzicht"><input type="text" name="prijs" required><br></td>
                        <td class="etOverzicht">
                            <select name="gerechtsoort" id="gerechtsoort">
                                <?php foreach($gerechtsoort as $soort): ?>
                                <?php if($soort['code'] != $type) continue; ?>
                                    <option value="<?= strtolower($soort['naam']) ?>"><?= $soort['naam'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </tbody>
            </table>

            <input type="submit" value="Submit" name="submit">
        </form>
    </div>

</body>
</html>