<?php
    require_once 'utils/shared.php';
    shared::isLoggedIn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excellent Taste</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="stylesheets/shared.css">
    <link rel="stylesheet" href="stylesheets/gegevens.css">
</head>
<body>
    <div class="navbar-collapse etNavbar">
        <ul class="nav navbar-nav navbar-left etNavbar">
            <li><a href="index.php">Home</a></li>
            <li><a href="reservering.php">Reserveringen</a></li>
            <li><a href="#" class="etMenu">Serveren</a></li>
            <li><a href="gegevens.php" class="etMenu etMenuCurrent">Gegevens</a></li>
        </ul>
    </div>

    <div class="centerForm etGegevens">
        <a class="etGegevensButton" href="menu.php?type=dranken">Dranken</a>
        <a class="etGegevensButton" href="menu.php?type=eten">Eten</a>
        <a class="etGegevensButton" href="klanten.php">Klanten</a>
    </div>
</body>

</html>