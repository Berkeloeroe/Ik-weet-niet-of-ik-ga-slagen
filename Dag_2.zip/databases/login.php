<?php

include_once 'database.php';

class login extends database 
{
    public function login($username, $password)
    {
        $query = "SELECT * FROM medewerker WHERE username = :username";
        $prepare = $this->dbh->prepare($query);
        $prepare->execute([
            'username' => $username
        ]);

        $result = $prepare->fetch(PDO::FETCH_ASSOC);

        // Voeg statement toe anders krijgen we errors
        if(isset($result) && !empty($result))
        {
            if($result['username'] == $username && $result['password'] == $password)
            {
                session_start();
                $_SESSION['username'] = $username;
                header('location: home.php');
            }        
        }
    
    }

}

?>