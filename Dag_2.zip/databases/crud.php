<?php

include_once __DIR__.'/database.php';

class crud extends database 
{
    public function select($statement)
    {
        $prepare = $this->dbh->prepare($statement);
        $prepare->execute();

        $rows = $prepare->fetchAll(PDO::FETCH_ASSOC);
            
        return $rows;   
    }

    // Reservering code
    public function addReservering($tafelNum, $datum, $tijd, $aantalPersonen, $aantalKinderen, $status, $datumToegevoegd, $allergien, $opmerkingen, $klantNum)
    {
        $sql = "INSERT INTO reservering(reservering_id, tafel, datum, tijd, aantal_personen, aantal_kinderen, status, datum_toegevoegd, allergien, opmerkingen, klant_id) 
                VALUES (:reservering_id, :tafel, :datum, :tijd, :aantal_personen, :aantal_kinderen, :status, :datum_toegevoegd, :allergien, :opmerkingen, :klant_id)";

        $stmt = $this->dbh->prepare($sql);
        $stmt->execute([
            'reservering_id' => NULL,
            'tafel' => $tafelNum,
            'datum' => $datum,
            'tijd' => $tijd,
            'aantal_personen' => $aantalPersonen,
            'aantal_kinderen' => $aantalKinderen,
            'status' => $status,
            'datum_toegevoegd' => $datumToegevoegd,
            'allergien' => $allergien,
            'opmerkingen' => $opmerkingen,
            'klant_id' => $klantNum
        ]);
    }

    public function updateReservering($reservering_id, $datum, $tijd, $tafel, $aantal)
    {
        $query = $this->dbh->prepare("UPDATE reservering SET reservering_id = :reservering_id, datum = :datum, tijd = :tijd, tafel = :tafel, aantal_personen = :aantal WHERE reservering_id = :reservering_id");
        
        $query->execute([
            'reservering_id' => $reservering_id,
            'datum' => $datum,
            'tijd' => $tijd,
            'tafel' => $tafel,
            'aantal' => $aantal,
        ]);
    }

    public function deleteReservering($reservering_id)
    {
        $query = $this->dbh->prepare("DELETE reservering, klant FROM reservering INNER JOIN klant WHERE reservering.reservering_id = :reservering_id AND reservering.klant_id = klant.klant_id");
        $query->execute([
            'reservering_id' => $reservering_id
        ]);
    }

    // Klanten code
    public function addKlant($naam, $telnummer, $email)
    {
        $sql = "INSERT INTO klant(klant_id, naam, telefoon, email) 
        VALUES (:id, :naam, :tel, :email)";

        $stmt = $this->dbh->prepare($sql);
        $stmt->execute([
            'id'        => NULL,
            'naam'      => $naam,
            'tel'       => $telnummer,
            'email'     => $email,
        ]);

        return $this->dbh->lastInsertId(); // Return de ID van klant
    }

    public function updateKlant($klant_id, $naam, $telefoon, $email)
    {
        $query = $this->dbh->prepare("UPDATE klant SET klant_id = :klant_id, naam = :naam, telefoon = :telefoon, email = :email WHERE klant_id = :klant_id");
        
        $query->execute([
            'klant_id' => $klant_id,
            'naam' => $naam,
            'telefoon' => $telefoon,
            'email' => $email,
        ]);
    }

    public function getKlant($klant_id)
    {
        $query = "SELECT * FROM klant WHERE klant_id = :klant_id";
        $prepare = $this->dbh->prepare($query);
        $prepare->execute([
            'klant_id' => $klant_id
        ]);

        $result = $prepare->fetch(PDO::FETCH_ASSOC);
        
        return $result;
    }
}

?>