<?php

include_once __DIR__.'/../utils/shared.php';

class database 
{
    protected $host;
    protected $dbh;
    protected $user;
    protected $pass;
    protected $db;
    protected $charset;

    function __construct($host = __DBHOST__, $user = __DBUSER__, $pass = __DBPASS__, $db = __DBNAME__, $charset = __DBCHARSET__)
    {
        $this->host = $host;
        $this->user = $user;
        $this->pass = $pass;
        $this->db = $db;
        $this->charset = $charset;

        try
        {
            $dsn = "mysql:host=$this->host;dbname=$this->db;charset=$this->charset";
            $this->dbh = new PDO($dsn, $this->user, $this->pass, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING)); 
        }
        catch(PDOException $e)
        {
            die("Unable to connect: " . $e->getMessage());
        }
    }
}

?>