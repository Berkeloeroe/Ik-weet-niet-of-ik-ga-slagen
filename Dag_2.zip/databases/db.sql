Create DATABASE excellenttaste;
USE excellenttaste;

CREATE TABLE klant
(
    klant_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    naam VARCHAR(20) NOT NULL,
    telefoon VARCHAR(11) NOT NULL,
    email VARCHAR(128) NOT NULL
);

CREATE TABLE reservering
(
    reservering_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    tafel INT NOT NULL,
    datum DATE NOT NULL,
    tijd TIME NOT NULL,
    aantal_personen INT NOT NULL,
    aantal_kinderen INT NOT NULL,
    status TINYINT(4) NOT NULL,
    datum_toegevoegd timestamp NOT NULL DEFAULT tijd,
    allergien text NULL,
    opmerkingen text NULL,

    klant_id INT NOT NULL,
    FOREIGN KEY(klant_id) REFERENCES klant(klant_id)
);

CREATE TABLE gerechtcategorien
(
    gerechtcategorie_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    code VARCHAR(3) NULL,
    naam VARCHAR(20) NULL
);

CREATE TABLE gerechtsoorten
(
    gerechtsoort_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    code VARCHAR(3) NULL,
    naam VARCHAR(20) NULL,

    gerechtcategorie_id INT NOT NULL,
    FOREIGN KEY(gerechtcategorie_id) REFERENCES gerechtcategorien(gerechtcategorie_id)
);

CREATE TABLE menuitems
(
    menuitems_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    code VARCHAR(255) NULL,
    naam VARCHAR(255) NULL,
    prijs VARCHAR(255) NOT NULL,

    gerechtsoort_id INT NOT NULL,
    FOREIGN KEY(gerechtsoort_id) REFERENCES gerechtsoorten(gerechtsoort_id)
);

CREATE TABLE bestellingen
(
    bestelling_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    aantal INT NULL,
    geserveerd TINYINT(4) NULL DEFAULT 0,

    reservering_id INT NOT NULL,
    menuitems_id INT NOT NULL,
    FOREIGN KEY(reservering_id) REFERENCES reservering(reservering_id),
    FOREIGN KEY(menuitems_id) REFERENCES menuitems(menuitems_id)
);

CREATE TABLE medewerker
(
    medewerker_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Je kan absoluut meeste statements in 1 INSERT INTO doen, maar ik vind dit wat leesbaarder
INSERT INTO medewerker(username, password) VALUES ('lverhoeven', 'excellenttaste');
INSERT INTO medewerker(username, password) VALUES ('mreule', '123');

INSERT INTO gerechtcategorien(gerechtcategorie_id, code, naam) VALUES (NULL, "bar", "Dranken");
INSERT INTO gerechtcategorien(gerechtcategorie_id, code, naam) VALUES (NULL, "kok", "Hapjes");
INSERT INTO gerechtcategorien(gerechtcategorie_id, code, naam) VALUES (NULL, "kok", "Hoofdgerechten");
INSERT INTO gerechtcategorien(gerechtcategorie_id, code, naam) VALUES (NULL, "kok", "Nagerechten");
INSERT INTO gerechtcategorien(gerechtcategorie_id, code, naam) VALUES (NULL, "kok", "Voorgerechten");

INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "bar", "Bieren", 1);
INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "bar", "Frisdranken", 1);
INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "bar", "Warme dranken", 1);
INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "bar", "Wijnen", 1);

INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Koude hapjes", 2);
INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Warme hapjes", 2);

INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Vegetarisch", 3);
INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Vis", 3);
INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Vlees", 3);

INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Ijs", 4);
INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Mousse", 4);

INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Koud", 5);
INSERT INTO gerechtsoorten(gerechtsoort_id, code, naam, gerechtcategorie_id) VALUES (NULL, "kok", "Warm", 5);